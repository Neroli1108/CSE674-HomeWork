#pragma once

#include<iostream>
#include<vector>

//class MinHeapNode
//{
//public:
//	MinHeapNode();
//	MinHeapNode(int,int);
//	~MinHeapNode();
//	int v;
//	int dist;
//private:
//
//};
//
//class MinHeap
//{
//public:
//	MinHeap();
//	MinHeap(int);
//	~MinHeap();
//	int size;
//	int capacity;
//	int *pos;
//	MinHeapNode* array;
//	
//private:
//
//};



class AdjListNode
{
public:
	AdjListNode();
	AdjListNode(int);
	AdjListNode(std::string);
	AdjListNode(std::string,std::string);
	~AdjListNode();
	int dest;
	int path;
	std::string weight;
	std::string name;
	AdjListNode* next;

};




class AdjList
{
public:
	AdjList();
	~AdjList();
	AdjListNode* head;

};



class Graph
{
public:
	Graph();
	~Graph();
	std::vector<AdjList> G;
	int V;
	void CreateGraph(int);
	void addEdge(int,int);
	void addEdgeSingle(int, int);
	void remoEdgeSingle(int, int);
	void remoEdge(int, int);
	void addEdgeSingle(std::string, std::string,std::string);
	void addEdge(std::string, std::string);
	void addEdgeSingle(std::string, std::string);
	void remoEdgeSingle(std::string, std::string);
	void remoEdge(std::string, std::string);
	void printGraph(std::vector<std::string>);
	void printWeightGraph();
	void printGraph();
	//std::vector<std::string> readCSV(std::istream& str);
	void CreateGraphByCSV(std::istream& str,std::vector<std::string>&);
	void CreateWeightedGraphByCSV(std::istream& str, std::vector<std::string>&);
	void PrintWDot(std::string name);
	void PrintShortPathDot(std::string name,std::string,std::string);
	void PrintDot(std::string name);
	void PrintUndirectedDot(std::string name);
	void PrintUndirectedWDot(std::string name);
	void PrintUnShortPathDot(std::string name, std::string src, std::string des);
	void CreateModifiedWeightedGraphByCSV(std::istream& str, std::vector<std::string>& input);
	void addVertices(std::string);
	void RemoVertices(std::string);
	/*int minDistance(std::vector<int> dist, std::vector<bool> sptSet);
	int printSolution(std::vector<int> dist, std::vector<int> n);*/
	void dijkstra(std::string srcname);
	std::string dijkstra(std::string srcname, std::string destname);
	void printArr(std::vector<int>dist, int n);

private:
	int csvVer;
};

